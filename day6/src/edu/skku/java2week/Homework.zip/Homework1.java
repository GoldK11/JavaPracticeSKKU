package edu.skku.java2week;

import java.util.Scanner;

public class Homework1 {

	public static void main(String[] args) {
		int[][] sc = new int[5][4];
		Scanner s = new Scanner(System.in);
		
		// ������ �Է�
		for (int r=0;r<5;++r) {
			for (int c=0; c<4;++c) {
				sc[r][c]=s.nextInt();
			}
		}//end for
		
		for (int r=0;r<5;++r) {
			double sum = (sc[r][1]+sc[r][2]+sc[r][3])/3;
			if (sum>=70) {
				System.out.println(sc[r][0]);
			}//end if
		}//end for
		
	}
	
	
	

}
