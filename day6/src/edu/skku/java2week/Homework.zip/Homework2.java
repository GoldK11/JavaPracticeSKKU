package edu.skku.java2week;

public class Homework2 {

	public static void main(String[] args) {
		int[][] alpha = new int[5][5];
		char al ='A';
		for (int r=0;r<5;++r) {
			for (int c=0;c<5;++c) {
				if (r%2==0) {
					alpha[r][c]=al;
					al+=1;
				}
				else {
					alpha[r][4-c]=al;
					al+=1;
				}
				
			}
		}
		for (int r=0;r<5;++r) {
			for (int c=0;c<5;++c) {
				System.out.printf("%2c",alpha[r][c]);
			}
			System.out.println();
		}
	
	}

}
